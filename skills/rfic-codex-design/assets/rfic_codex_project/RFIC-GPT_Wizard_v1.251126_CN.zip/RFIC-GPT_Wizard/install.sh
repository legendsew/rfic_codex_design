#!/bin/bash
user_directory=$(pwd)
list="check_list.txt"

# File Integrity Check
missing_count=0
while IFS= read -r file; do
	if [[ ! -e "$user_directory/$file" ]]; then
		echo "Missing file: $file"
		missing_count=$((missing_count+1))
	fi
done < "$list"

if [ $missing_count -ne 0 ]; then
	if [ $missing_count -eq 1 ]; then
	echo "ERROR: Missing $missing_count file! Please check and re-download."
	else
	echo "ERROR: Missing $missing_count files! Please check and re-download."
	fi
exit 1
fi


# Variables
tool_root=$user_directory
EmptyBoxPath="$tool_root/RFIC-GPT_Wizard_Active/EmptyBox"
setupPath="$tool_root/setupPath"
RFIC_GPT_Wizard_PATH="RFIC_GPT_Wizard_PATH = \"$tool_root\""

# Check setupPath
if [ -f "$setupPath" ]; then
rm "$setupPath"
fi

# cds.lib
echo -e "1.  Please specify the 'cds.lib' file path. If you are an individual user, the 'cds.lib' is usually in your startup path.
Make sure your account has the permission to modify this 'cds.lib'.
(e.g. /tools/IC618/share/cdssetup/cds.lib)\n"
while true; do
read cds_file_dir
if [ -f "$cds_file_dir" ]; then
echo -e "\nThe 'cds.lib' file exists."
	if grep -qF "DEFINE EmptyBox" "$cds_file_dir"; then
        sed -i '/^DEFINE EmptyBox/ s/^/#/' "$cds_file_dir"
	echo "DEFINE EmptyBox $EmptyBoxPath" >> "$cds_file_dir"
	echo -e "\nEmptyBox is added successfully!\n"
	#echo -e "\nEmptyBox already exists."
	break
	else
	echo "DEFINE EmptyBox $EmptyBoxPath" >> "$cds_file_dir"
	echo -e "\nEmptyBox is added successfully!\n"
	break
	fi
else
	echo -e "Warning: 'cds.lib' file not found. Please check your path and re-enter.\n"
fi
done

# .cdsinit
echo -e "2.  Please specify the '.cdsinit' file path. If you are an individual user, the '.cdsinit' path is the same as the 'cds.lib' path.
(e.g. /tools/IC618/tools.lnx86/dfII/local/.cdsinit)\n"
while true; do
read cdsinit_file_dir
if [ -f "$cdsinit_file_dir" ]; then
echo -e "\nThe '.cdsinit' file exists."
	if grep -qF "RFIC_GPT_Wizard_PATH" "$cdsinit_file_dir"; then
		sed -i '/^RFIC_GPT_Wizard_PATH/ s/^/;/' "$cdsinit_file_dir"
		echo "$RFIC_GPT_Wizard_PATH" >> "$cdsinit_file_dir"
		echo -e "RFIC-GPT Wizard path is added successfully!\n"
	else
	echo "$RFIC_GPT_Wizard_PATH" >> "$cdsinit_file_dir"
	echo -e "RFIC-GPT Wizard path is added successfully!\n"
	fi
break
else
	if [[ ! $cdsinit_file_dir == /* ]] || [[ ! $cdsinit_file_dir =~ /.cdsinit$ ]]; then
	echo -e "Warning: Path not valid. Please check your path and re-enter.\n"
	else
	echo -e "\nWarning: The '.cdsinit' file does not exist."
	echo -e "Do you want to create a new '.cdsinit' as '$cdsinit_file_dir'? (y/n)\n"
	read answer1
		if [ "$answer1" = "y" ] || [ "$answer1" == "Y" ] || [ "$answer1" == "yes" ] || [ "$answer1" == "Yes" ]; then
		touch "$cdsinit_file_dir"
			if [ -f "$cdsinit_file_dir" ]; then
			echo "$RFIC_GPT_Wizard_PATH" >> "$cdsinit_file_dir"
			echo -e "\n'.cdsinit' file has been created successfully!"
			echo -e "RFIC-GPT Wizard path is added successfully!\n"
			break
			else
			echo -e "'Failed. Please check your path and re-enter.\n"
			fi
		else
		echo -e "\nPlease specify a new path to create a '.cdsinit' file."
		echo -e "e.g. /tools/IC618/tools.lnx86/dfII/local/.cdsinit\n"
		while true; do
		read new_cdsinit
			if [[ ! $new_cdsinit == /* ]] || [[ ! $new_cdsinit =~ /.cdsinit$ ]]; then
			echo -e "Warning: Path not valid.\n"
			else
			touch "$new_cdsinit"
				if [ -f "$new_cdsinit" ]; then
				echo "$RFIC_GPT_Wizard_PATH" >> "$new_cdsinit"
				echo -e "\n'.cdsinit' file has been created successfully!"
				echo -e "RFIC-GPT Wizard path is added successfully!\n"
				break
				else
				echo -e "Failed. Please check your path and re-enter.\n"
				fi
			fi
		done
		break
		fi
	fi
fi
done

# Create setupPath
touch "$setupPath"
echo "tool_root=\"$tool_root\"" >> "$setupPath"
if [ -f "$cdsinit_file_dir" ]; then
echo "cdsinit_file=\"$cdsinit_file_dir\"" >> "$setupPath"
elif [ -f "$new_cdsinit" ]; then
echo "cdsinit_file=\"$new_cdsinit\"" >> "$setupPath"
fi
echo "cds_file=\"$cds_file_dir\"" >> "$setupPath"

# Start-up on Boot
echo -e "3.  Do you want to set RFIC-GPT Wizard as a startup item for Cadence Virtuoso? (y/n)\n"
read answer2
if [ "$answer2" = "y" ] || [ "$answer2" == "Y" ] || [ "$answer2" == "yes" ] || [ "$answer2" == "Yes" ]; then
RFIC_GPT_Wizard_Init="ciwMenuInit() load(strcat(RFIC_GPT_Wizard_PATH \"/Start.il\"))"
RFIC_GPT_Wizard_Init2="ciwMenuInit() loadContext(strcat(RFIC_GPT_Wizard_PATH "
RFIC_GPT_Wizard_Init3=";ciwMenuInit() loadContext(strcat(RFIC_GPT_Wizard_PATH "


if grep -qF "$RFIC_GPT_Wizard_Init" "$cdsinit_file_dir"; then
sed -i "s/$RFIC_GPT_Wizard_Init2/$RFIC_GPT_Wizard_Init3/g" "$cdsinit_file_dir"
echo "$RFIC_GPT_Wizard_Init" >> "$cdsinit_file_dir"
echo -e "\nSuccessfully set RFIC-GPT Wizard as a startup item!\n"
else
echo "$RFIC_GPT_Wizard_Init" >> "$cdsinit_file_dir"
echo -e "\nSuccessfully set RFIC-GPT Wizard as a startup item!\n"
fi
else
echo "Do not set RFIC-GPT Wizard as a startup item.\n"
fi
echo "Installation completed."
