
RFIC_Generator_work_dir=getWorkingDir()
workDir_Passive_tool=strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive")
workDir_Passive_tool_trans= strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive")
loadContext(strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_Menu.cxt") t)
RFIC_Generator_glovar_active()
unless(isDir(strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work")) system(strcat("mkdir " RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work")))
unless(isDir(strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive")) system(strcat("mkdir " RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive")))
unless(isDir(strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive/Transformer")) system(strcat("mkdir " RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive/Transformer")))
unless(isDir(strcat(RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive/inductor")) system(strcat("mkdir " RFIC_Generator_work_dir "/RFIC-GPT_Wizard_work/RFIC-GPT_Wizard_Passive/inductor")))



;##############cell_sub############

;###############cell->cellsub##


;##############cell_sub############

RFIC_GPT_Wizard_Passive = hiCreateMenuItem(
    ?name 'RFIC_GPT_Wizard_Passive
    ?itemText "RFIC-GPT Wizard"
    ?callback "_Passive_tool_APP_FieldFormCB()"
)
;###############cell->cellsub##
procedure(readme_nitride()
view(strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_documentation/about.txt"))
)

readme_MenuItem = hiCreateMenuItem(
    ?name 'readme_MenuItem
    ?itemText "About"
    ?callback "readme_nitride()" ;;; prints A in the CIW
    )

RFIC_GPT_tools = hiCreatePulldownMenu(
    'RFIC_GPT_tools
    "RFIC-GPT Wizard"  ; The munu name, U can named by your company name.
    list(RFIC_GPT_Wizard_Passive readme_MenuItem) ; list
    )
    hiInsertBannerMenu((hiGetCIWindow) 'RFIC_GPT_tools (hiGetNumMenus (hiGetCIWindow)))



/***************************************************************************/

websitepath = strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_documentation/Welcome.html")
readOurWebSite(websitepath)
Inductor_TypeGuide_rficgpt_view_fileName = strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_documentation/picture/Wizard_Inductor.png")
Transformer_TypeGuide_rficgpt_view_fileName=strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_documentation/picture/Wizard_Transformer.png")

RFIC_GPT_Pro_view_filename=strcat(RFIC_GPT_Wizard_PATH "/RFIC-GPT_Wizard_documentation/picture/RFIC-GPT-Pro.png")

Inductor_TypeGuide_picture=hiLoadImageFile(
    Inductor_TypeGuide_rficgpt_view_fileName
    800
    600
)

Inductor_TypeGuide_view=hiCreateLabel(
    ?name         'Inductor_TypeGuide_view
    ?labelIcon     Inductor_TypeGuide_picture
)

RFIC_GPT_Pro_picture=hiLoadImageFile(
    RFIC_GPT_Pro_view_filename
    1000
    3200
)
RFIC_GPT_Pro_introduction_view=hiCreateLabel(
    ?name         'RFIC_GPT_Pro_introduction_view
    ?labelIcon     RFIC_GPT_Pro_picture
)


Inductor_viewFrameField=hiCreateFrameField(
               ?name         'Inductor_viewlableField
               ?labelText     "Inductor Types"
)

Inductor_ForMore_viewFrameField=hiCreateFrameField(
    ?name         'Inductor_ForMore_viewFrameField
    ?labelText     "For more inductor types, please refer to"
)

Inductor_jumptoRFICPRO_ExcelViewField=hiCreateFormButton(
    ?name          'Inductor_jumptoRFICPRO_ExcelViewField
    ?buttonText    "RFIC-GPT Pro"
    ?callback      "hiDisplayForm(RFIC_GPT_Pro_view_Form 0:0)"
)

Inductor_view_Form=hiCreateAppForm(
                 ?name              'Inductor_view_Form
                 ?formTitle         "Inductor_view"
                ?fields            list(               
        list(Inductor_viewFrameField               011 : 011       820 : 460    0     )                                                             
        list(Inductor_TypeGuide_view       015 : 042        100 : 200      0      )
        
        list(Inductor_ForMore_viewFrameField        011 : 460+10    820 : 60    0)
        list(Inductor_jumptoRFICPRO_ExcelViewField 185 : 490       450 : 25     0)
)
                ?buttonLayout 'Close

)
hiSetFormMinMaxSize(Inductor_view_Form 850:560 nil) 


Transformer_TypeGuide_view_file=hiLoadImageFile(
Transformer_TypeGuide_rficgpt_view_fileName
800
600
)
  
Transformer_TypeGuide_view=hiCreateLabel(
               ?name         'Transformer_TypeGuide_view
               ?labelIcon     Transformer_TypeGuide_view_file
)

Transformer_viewFrameField = hiCreateFrameField(
       ?name      'Transformer_viewFrameField
       ?labelText "Transformer Types"
)   

Transformer_ForMore_viewFrameField=hiCreateFrameField(
    ?name         'Transformer_ForMore_viewFrameField
    ?labelText     "For more transformer types, please refer to"
)

Transformer_jumptoRFICPRO_ExcelViewField=hiCreateFormButton(
    ?name          'Transformer_jumptoRFICPRO_ExcelViewField
    ?buttonText    "RFIC-GPT Pro"
    ?callback      "hiDisplayForm(RFIC_GPT_Pro_view_Form 0:0)"
)

Transformer_view_Form=hiCreateAppForm(
                 ?name              'Transformer_view_Form
                 ?formTitle         "Transformer_view"
                ?fields            list(  

           list(Transformer_viewFrameField      011 : 011       820 : 460    0        )                   
           list(Transformer_TypeGuide_view              015 : 042        100 : 200      0      )
           list(Transformer_ForMore_viewFrameField        011 : 460+10    820 : 60    0)
           list(Transformer_jumptoRFICPRO_ExcelViewField 185 : 490       450 : 25     0)

)
            ?buttonLayout 'Close
)

hiSetFormMinMaxSize(Transformer_view_Form 850:560 nil) 

RFIC_GPT_Pro_viewFrameField=hiCreateFrameField(
    ?name         'RFIC_GPT_Pro_viewFrameField
    ?labelText     ""
)

RFIC_GPT_Pro_ExcelOutputlableField=hiCreateOutputStringField(
    ?name         'RFIC_GPT_Pro_ExcelOutputlableField
    ?value       strcat(
                   "RFIC-GPT Online Wizard (hereinafter referred to as the \n"
                   "Wizard) is an auxiliary tool affiliated with RFIC-GPT \n"
                   "Online. It allows users to import GDSII layouts or \n"
                   "schematics and fine-tune imported layouts \n"
                   "conveniently. The Wizard also supports users to generate\n"
                   "GDSII layouts for inductors and transformers based on\n"
                   "specified geometric parameters.\n"
                   "\n"
                   "In contrast,RFIC-GPT Pro is a powerful and full-featured\n"
                   "generative solution for RFIC designers based on AI \n"
                   "models and algorithms. \n"
                   "\n"
                   "It provides a seamless and streamlined workflow for \n"
                   "designers. The RFIC-GPT Pro includes but not limited \n"
                   "to the following features:\n"
                   "\n"
                   " 1.Built-in AI algorithm with broad design space\n"
                   " 2.Tens of passive device types\n"
                   " 3.Numerous number of matching network architectures\n"
                   " 4.Automatic Generation of schematics and symbols\n"
                   " 5.Automatic Generation of ground plane, guard ring\n"
                   "   , PGS, and dummy\n"
                   " 6.Automatic Generation of Active circuits\n"
                   " 7.Automatic Generation of various RFIC IP:\n" 
                   "   Spec-to-Layout\n"
                   " 8.Circuit-level, performance-driven active and passive \n"
                   " devices co-optimization\n"
                   " ......\n"
                   "\n"
                   "For a graphical illustration, please refer to:\n")
     ;?font "roman"

)

RFIC_GPT_Pro_jumptoRFICPRO_ExcelViewField=hiCreateFormButton(
    ?name          'RFIC_GPT_Pro_jumptoRFICPRO_ExcelViewField
    ?buttonText    "RFIC-GPT Pro"
    ?callback      "hiDisplayForm(RFIC_GPT_Pro_view_Form 0:0)"
)

RFIC_GPT_Pro_view_Form=hiCreateAppForm(
    ?name              'RFIC_GPT_Pro_view_Form
    ?formTitle         "RFIC-GPT Pro Illustration"
   ?fields            list(                                                            
list(RFIC_GPT_Pro_introduction_view       021 : 031        1000 : 3200      0      )
)
   ?buttonLayout 'Close

)
hiSetFormMinMaxSize(RFIC_GPT_Pro_view_Form 1000:3200 nil) 

