#!/bin/bash
user_directory=$(pwd)
source "$user_directory/setupPath"
RFIC_GPT_Wizard_PATH="RFIC_GPT_Wizard_PATH = \"$tool_root\""
RFIC_GPT_Wizard_init="ciwMenuInit() load(strcat(RFIC_GPT_Wizard_PATH \"/Start.il\"))"
EmptyBoxPath="$tool_root/RFIC-GPT_Wizard_Active/EmptyBox"

# Preventive Inquiry
echo -e "Do you want to uninstall RFIC-GPT Wizard? (y/n)\n"
read answer
if [ "$answer" = "y" ] || [ "$answer" == "Y" ] || [ "$answer" == "yes" ] || [ "$answer" == "Yes" ]; then
:
else
exit 1
fi

# .cdsinit
if [ -f "$cdsinit_file" ]; then

	if grep -qF "$RFIC_GPT_Wizard_PATH" "$cdsinit_file"; then
	sed -i "\#$RFIC_GPT_Wizard_PATH#d" "$cdsinit_file"
	fi

	if grep -qF "$RFIC_GPT_Wizard_init" "$cdsinit_file"; then
	sed -i "\#$RFIC_GPT_Wizard_init#d" "$cdsinit_file"
	fi

else
echo -e "ERROR: '.cdsinit' file not found! Please ensure your '.cdsinit' file path is as specified during installation."
exit 1
fi

# cds.lib
if [ -f "$cds_file" ]; then

	if grep -qF "DEFINE EmptyBox $EmptyBoxPath" "$cds_file"; then
	sed -i "\#DEFINE EmptyBox $EmptyBoxPath#d" "$cds_file"
	fi

else
echo -e "ERROR: 'cds.lib' file not found! Please ensure your 'cds.lib' file path is as specified during installation."
exit 1
fi

echo -e "\nRFIC-GPT Wizard has been uninstalled."
